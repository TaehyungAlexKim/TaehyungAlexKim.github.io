'use strict';
var http = require('http');
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
const { post } = require('jquery');
const { request } = require('express');

var port = process.env.PORT || 3000;

var app = express();

app.use(bodyParser.urlencoded({ extended: false }));

app.use("/", express.static("pages"));

// create a mssql SQL object from mssql module (package)
var sql = require("mssql");

// create configuration object literal for connection string
// must use SQL authentication
// note the the \\ in the SQL server name
var config = {
    user: 'sa',
    password: '1q2w3e4r!',
    server: 'DESKTOP-49FEL0I\\SQLEXPRESS',
    database: 'store'
};

//server default page on http://localhost:3000/
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname + "/pages/index.html"));
});

// connect to the store database
app.post('/api/data', (request, response) => {
    let result = request.body;
    // Find Button
    if (result.type == "find") {
        sql.connect(config, function (err) {

            if (err) {
                console.log(err);
            }
            // create a SQL query string with place holder values
            let queryString = "SELECT CusID, FirstName, LastName, Address, City, Province, PostalCode FROM Customers WHERE CusID=" + result.cusID;

            // create Request object
            let request = new sql.Request();

            // input the parameter values and associated SQL Server types
            request.query(queryString, function (err, recordset) {
                if (err) {
                    console.log(err);
                }
                // if the values exist
                if (recordset.recordsets[0].length == 1) {
                    // output recordset as a response for debugging purposes
                    result.customerID = recordset.recordsets[0][0].CusID;
                    result.firstName = recordset.recordsets[0][0].FirstName;
                    result.lastName = recordset.recordsets[0][0].LastName;
                    result.address = recordset.recordsets[0][0].Address;
                    result.city = recordset.recordsets[0][0].City;
                    result.province = recordset.recordsets[0][0].Province;
                    result.postal = recordset.recordsets[0][0].PostalCode;
                    response.send(result);
                } else {
                    //if the values not exist
                    result.customerID = "";
                    result.firstName = "";
                    result.lastName = "";
                    result.address = "";
                    result.city = "";
                    result.province = "";
                    result.postal = "";
                    response.send(result);
                }
            });
        });
    }
    // Update Button
    if (result.type == "update") {
        // connect to the store database
        sql.connect(config, function (err) {
           
            if (err) {
                console.log(err);
            };
            let firstName = result.firstName;
            let lastName = result.lastName;
            let address = result.address;
            let city = result.city;
            let province = result.province;
            let postal = result.postal;

            // check the exist values
            let queryString = "SELECT CusID, FirstName, LastName, Address, City, Province, PostalCode FROM Customers WHERE CusID=" + result.cusID;

            // create Request object
            let request = new sql.Request();

            // input the parameter values and associated SQL Server types
            request.query(queryString, function (err, recordset) {
                if (err) {
                    console.log(err);
                }
                // if the values exist
                if (recordset.recordsets[0].length == 1) {
                    let queryString = "UPDATE Customers SET FirstName = @First , LastName = @Last, Address = @Address, City = @City, Province = @Province, PostalCode = @PostalCode WHERE CusID=" + result.cusID;

                    // create Request object
                    let request = new sql.Request();

                    // input the parameter values and associated SQL Server types
                    request.input("First", sql.VarChar(50), firstName)
                        .input("Last", sql.VarChar(50), lastName)
                        .input("Address", sql.VarChar(50), address)
                        .input("City", sql.VarChar(50), city)
                        .input("Province", sql.VarChar(25), province)
                        .input("PostalCode", sql.VarChar(10), postal)

                        // chain the query
                        .query(queryString, function (err, recordset) {
                            if (err) {
                                console.log(err);
                            } else {
                                console.log("Update Success");
                            }
                        });
                } else {
                    console.log("No data");
                }

            });
        });
    }
    // Delete Button
    if (result.type == "delete") {
        sql.connect(config, function (err) {

            if (err) {
                console.log(err);
            }
            // create a SQL query string with place holder values
            let queryString = "DELETE FROM Customers WHERE CusID=" + result.cusID;

            // create Request object
            let request = new sql.Request();

            // input the parameter values and associated SQL Server types
            request.query(queryString, function (err, recordset) {
                if (err) {
                    console.log(err);
                }
                // output recordset as a response for debugging purposes
                result.customerID = "";
                result.firstName = "";
                result.lastName = "";
                result.address = "";
                result.city = "";
                result.province = "";
                result.postal = "";
                response.send(result);
            });
        });
    }
    // Add Button
    if (result.type == "add") {
        // connect to the store database
        sql.connect(config, function (err) {

            if (err) {
                console.log(err);
            }
            let firstName = result.firstName;
            let lastName = result.lastName;
            let address = result.address;
            let city = result.city;
            let province = result.province;
            let postal = result.postal;

            // create a SQL query string with place holder values
            let queryString = "INSERT INTO Customers (FirstName, LastName, Address, City, Province, PostalCode) VALUES (@First, @Last, @Address, @City, @Province, @PostalCode)";

            // create Request object
            let request = new sql.Request();

            // input the parameter values and associated SQL Server types
            request.input("First", sql.VarChar(50), firstName)
                .input("Last", sql.VarChar(50), lastName)
                .input("Address", sql.VarChar(50), address)
                .input("City", sql.VarChar(50), city)
                .input("Province", sql.VarChar(25), province)
                .input("PostalCode", sql.VarChar(10), postal)
                // chain the query
                .query(queryString, function (err, recordset) {
                    if (err) {
                        console.log(err);
                    } else {
                        console.log("Add Success.")
                        // create the SQL to get the last "identity" field value
                        queryString = "SELECT @@IDENTITY AS 'identity'";
                        request.query(queryString, function (err, returnVal) {
                            if (err) {
                                console.log(err);
                            }
                            // extract the "CusID" assigned by SQL Server for the last INSERT
                            let identValue = returnVal.recordset[0].identity;
                            // Update CustomerID
                            result.customerID = identValue;
                            response.send(result);
                        });
                    }
                });
        });
    }
});

//server listens to port 
app.listen(port, function () {
    console.log("Server is running on port " + port);
});