<?php
session_start();

define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
include _SERVER_PATH_ . 'common.php';
$db_conn = connectDB();

//logger('Post', $_POST);
//logger('Session', $_SESSION);

if($_POST['submit'] === 'add-create'){
	//save order data to session
	if( !isset($_SESSION['orderSummary']) ){
		$_SESSION['orderSummary']=[];
	}

	//remove submit post data
	$orderData=$_POST;
	unset($orderData['submit']);
	
	//add new order to order summary
	$order=[
		'type'=>'create',
		'detail'=>$orderData
	];
	$_SESSION['orderSummary'][] = $order;

	//redirect
	header('Location: ordersummary.php');
}else if($_POST['submit'] === 'add-custom'){
	//save order data to session
	if( !isset($_SESSION['orderSummary']) ){
		$_SESSION['orderSummary']=[];
	}

	//remove submit post data
	$orderData=$_POST;
	unset($orderData['submit']);

	//add new order to order summary
	$order=[
		'type'=>'custom',
		'detail'=>$orderData
	];
	$_SESSION['orderSummary'][] = $order;	

	//redirect
 	header('Location: ordersummary.php');
}else if( strpos( $_POST['submit'], 'reorder') >= 0 ){
	$orderDetailID=explode('-', $_POST['submit'])[1];

	//add new reorder data to order summary	
	$order=getOrderDetailDataById($db_conn, $orderDetailID);
	$_SESSION['orderSummary'][] = $order;	

	//logger('order', $order);

	//redirect
 	header('Location: ordersummary.php');
}