<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

	<link rel="stylesheet" href="./css/style.css">

	<?php
	define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
	include _SERVER_PATH_ . 'common.php';
	$db_conn = connectDB();
	?>

	<title>Group2 - Pizza store</title>
</head>

<body>
	<!-- Load navigationMenu -->
	<?php
	//define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
	include _SERVER_PATH_ . 'navigationMenu.php';
	?>

	<div class="container-md">
		<?php
		//logger('Session', $_SESSION); 
		?>

		<?php if (!isset($_SESSION['customerID'])) { ?>
			<p class="error">No customer information for this order. Please try again.</p>
			<a href="./">Home</a>
		<?php } else { ?>

			<div class="order-summary">
				<?php include _SERVER_PATH_ . './summary.php'; ?>
				<?php include _SERVER_PATH_ . './deliverydetails.php'; ?>
				<form action="ordercomplete.php" method="POST">
					<div class="delivery-type">
						<h3>Delivery Type</h3>
						<label>
							<input type="radio" name="deliveryType" value="delivery" checked>
							Delivery
						</label>
						<label>
							<input type="radio" name="deliveryType" value="pickup">
							Pickup
						</label>
					</div>
					<div class="buttons">
						<a class="button" href="./orderpizza.php">Add Another</a>
						<a class="button" href="./previousorders.php">Previous Orders</a>
						<button class="button" type="submit" value="complete">Complete Order</button>
					</div>
				</form>
			</div>

		<?php } ?>
	</div>

	<body>

</html>