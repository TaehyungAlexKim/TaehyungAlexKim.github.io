<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body>
    <!-- Load navigationMenu -->
    <?php
    //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'navigationMenu.php'; ?>

    <?php
    //logger('get', $_GET);
    //logger('Session', $_SESSION);

    $menu = getPizzaMenu($db_conn);
    $dough = getDough($db_conn);
    $sauce = getSauce($db_conn);
    $cheese = getCheese($db_conn);
    $toppings = getToppings($db_conn);

    $isCreatePizza = $_GET['create'] === 'y';
    $isCustomPizza = $_GET['create'] === 'n';

    $pizza;
    if ($isCustomPizza) {
        $pizza = getPizzaDataById($db_conn, $_GET['pizza-id']);
    } ?>

    <?php if ($isCustomPizza && isset($pizza) || $isCreatePizza) { ?>
        <div class="container-md">
            <?php
            //if customerID is not set in session then show error
            if (!isset($_SESSION['customerID'])) { ?>
                <p class="error">No customer information for this order. Please try again.</p>
                <a href="./">Home</a>
            <?php } else { ?>
                <form action="processpizzaorder.php" method="POST">
                    <div class="pizza-layout">
                        <?php if ($isCustomPizza) { ?>
                            <div class="pizza-layout-image">
                                <img src="https://img.pizza/300/300">
                            </div>
                            <div class="pizza-layout-content">
                                <h2><?= $pizza['name']; ?></h2>
                                <p><?= $pizza['description']; ?></p>
                            <?php } ?>

                            <?php if ($isCreatePizza) { ?>
                                <div class="pizza-layout-image">
                                    <img src="https://img.pizza/300/300">
                                </div>
                                <div class="pizza-layout-content">
                                    <h2 class="name">Create Pizza</h2>
                                <?php } ?>

                                <?php if ($isCreatePizza) { ?>
                                    <p>Dough</p>
                                    <ul>
                                        <?php
                                        $index = -1;
                                        foreach ($dough as $key => $item) {
                                            $index++; ?>
                                            <li>
                                                <label>
                                                    <input type="radio" name="dough" value="<?= $key; ?>" <?= ($index === 0) ? 'checked' : '' ?>>
                                                    <?= $item['name']; ?> - $<?= $item['price']; ?>
                                                </label>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                    <p>Sauce</p>
                                    <ul>
                                        <?php
                                        $index = -1;
                                        foreach ($sauce as $key => $item) {
                                            $index++; ?>
                                            <li>
                                                <label>
                                                    <input type="radio" name="sauce" value="<?= $key; ?>" <?= ($index === 0) ? 'checked' : '' ?>>
                                                    <?= $item['name']; ?> - $<?= $item['price']; ?>
                                                </label>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                    <p>Cheese</p>
                                    <ul>
                                        <?php
                                        $index = -1;
                                        foreach ($cheese as $key => $item) {
                                            $index++; ?>
                                            <li>
                                                <label>
                                                    <input type="radio" name="cheese" value="<?= $key; ?>" <?= ($index === 0) ? 'checked' : '' ?>>
                                                    <?= $item['name']; ?> - $<?= $item['price']; ?>
                                                </label>
                                            </li>
                                        <?php } ?>
                                    </ul>
                                <?php } ?>

                                <p>Toppings</p>
                                <ul>
                                    <?php foreach ($toppings as $key => $item) { ?>
                                        <li>
                                            <?php
                                            $isChecked = false;

                                            if ($isCustomPizza) {
                                                $isChecked = in_array($key, $pizza['toppings']); ?>
                                                <label class="<?= ($isChecked ? 'topping-disabled' : ''); ?>">
                                                <?php } ?>

                                                <?php if ($isCreatePizza) { ?>
                                                    <label>
                                                    <?php } ?>

                                                    <?php if ($isChecked) { ?>
                                                        <input type="checkbox" checked>
                                                    <?php } else { ?>
                                                        <input type="checkbox" name="toppings[]" value="<?= $key; ?>">
                                                    <?php } ?>
                                                    <?= $item['name']; ?> - $<?= $item['price']; ?>
                                                    </label>
                                        </li>
                                    <?php } ?>
                                </ul>
                                <?php if ($isCustomPizza) { ?>
                                    <input type="hidden" name="pizzaID" value="<?= $_GET['pizza-id']; ?>">
                                    <button class="button add-button" type="submit" name="submit" value="add-custom">Add to Order</button>
                                <?php } elseif ($isCreatePizza) { ?>
                                    <button class="button add-button" type="submit" name="submit" value="add-create">Add to Order</button>
                                <?php } ?>
                                </div>
                            </div>
                </form>
            <?php } ?>
        </div>
    <?php } ?>
</body>

</html>