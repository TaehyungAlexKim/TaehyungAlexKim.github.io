<?php
// time and date correction.
date_default_timezone_set('America/Toronto');


// For database connection
define("DBHOST", "localhost");
define("DBDB",   "pizza_store");
define("DBUSER", "pizza_store");
define("DBPW", "Lampproject1");


//Connect to database using PDO method
function connectDB()
{
    $dsn = "mysql:host=" . DBHOST . ";dbname=" . DBDB . ";charset=utf8";
    try {
        $db_conn = new PDO($dsn, DBUSER, DBPW);
        return $db_conn;
    } catch (PDOException $e) {
        echo "<p>Error opening database <br/>\n" . $e->getMessage() . "</p>\n";
        exit(1);
    }
}

function sanitize_html($arg)
{
    $sanitizedArray = array();
    foreach ($arg as $key => $value) {
        $sanitizedArray[$key] = htmlentities($value);
    }
    //return the array of sanitized values
    return $sanitizedArray;
}

function check_user($dbc, $arr)
{
    $emailaddr = $arr['email'];
    $stmt = $dbc->prepare("SELECT count(*) as `count` FROM `tblCustomers` WHERE email= '$emailaddr';");
    if (!$stmt) {
        echo "Error " . $dbc->errorCode() . "\nMessage " . implode($dbc->errorInfo()) . "\n";
        exit(1);
    }
    $status = $stmt->execute();
    if ($status) {
        if ($stmt->rowCount() > 0) {
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                return $row['count'];
            }
        }
    } else {
        echo "Error " . $stmt->errorCode() . "\nMessage " . implode($stmt->errorInfo()) . "\n";
        exit(1);
    }
}

function create_user($dbc, $arr)
{
    // Insert New customer here.

    $stmt = $dbc->prepare('INSERT INTO tblCustomers (customerName, email, address1, address2, city, province, postalcode) values(:customerName, :email, :address1, :address2, :city, :province, :postalcode)');

    if (!$stmt) {
        echo "Error " . $dbc->errorCode() . "\nMessage " . implode($dbc->errorInfo()) . "\n";
        exit(1);
    }
    $data = array(":customerName" => $arr['customerName'], ":email" => $arr['email'], ":address1" => $arr['address1'],  ":address2" => $arr['address2'], ":city" => $arr['city'], ":province" => $arr['province'], ":postalcode" => $arr['postalcode']);
    $status = $stmt->execute($data);
    if (!$status) {
        echo "Error " . $stmt->errorCode() . "\nMessage " . implode($stmt->errorInfo()) . "\n";
        exit(1);
    }
    return $status;
}
function getCustomerName($dbc, $email)
{
    $stmt = $dbc->prepare("SELECT customerName FROM `tblCustomers` WHERE email= '$email';");
    if (!$stmt) {
        echo "Error " . $dbc->errorCode() . "\nMessage " . implode($dbc->errorInfo()) . "\n";
        exit(1);
    }
    $status = $stmt->execute();
    if ($status) {
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $_SESSION['customerName'] = $row['customerName'];
        } else {
            echo "<p>Nothing to output</p>\n";
        }
    }
}
function show_customer_information($dbc, $email)
{
    $stmt = $dbc->prepare("SELECT customerID, email, customerName, address1, address2, city, province, postalcode FROM `tblCustomers` WHERE email= '$email';");
    if (!$stmt) {
        echo "Error " . $dbc->errorCode() . "\nMessage " . implode($dbc->errorInfo()) . "\n";
        exit(1);
    }
    $status = $stmt->execute();
    $customerID = null;
    if ($status) {
        if ($stmt->rowCount() > 0) {
            // draw the table header
            echo "<div class =\"container-md\">";
            echo "<br><h2>Your Deliverly Information</h2><br>
            <table class=\"table\">
                <thead>
                    <tr>
                        <th scope=\"col\">E-mail</th>
                        <th scope=\"col\">Name</th>
                        <th scope=\"col\">Address1</th>
                        <th scope=\"col\">Address2</th>
                        <th scope=\"col\">City</th>
                        <th scope=\"col\">Province</th>
                        <th scope=\"col\">Postal Code</th>
                    </tr>
                </thead>
                <tbody>";

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                foreach ($row as $field => $v) {
                    if ($field === 'customerID') {
                        $customerID = $v;
                        continue;
                    }


                    print "<td>$v</td>";
                }
                print "</tr>\n";
            }
            // end the table
            echo "</tbody></table></div>";
        } else {
            echo "<p>Nothing to output</p>\n";
        }
    }
    return $customerID;
}

function logger($label, $data)
{
    echo '<pre style="text-align:left;">';
    print_r($label . '<br>');
    print_r($data);
    echo '</pre>';
}

function getPizzaMenu($dbc)
{
    // $items=[
    //     '0'=>[
    //         'name'=>'Meat Lovers',
    //         'dough'=>1,
    //         'cheese'=>1,
    //         'sauce'=>1,
    //         'toppings'=>['1', '2'],
    //         'price'=>100,
    //         'image'=>'https://img.pizza/300/300'
    //     ],
    //     '1'=>[
    //         'name'=>'Cheese',
    //         'dough'=>1,
    //         'cheese'=>1,
    //         'sauce'=>1,
    //         'toppings'=>['1', '2'],
    //         'price'=>100,
    //         'image'=>'https://img.pizza/300/300'
    //     ],
    //     '2'=>[
    //         'name'=>'Vegan',
    //         'dough'=>2,
    //         'cheese'=>2,
    //         'sauce'=>2,
    //         'toppings'=>['1', '2'],
    //         'price'=>100,
    //         'image'=>'https://img.pizza/300/300'
    //     ],
    //     '3'=>[
    //         'name'=>'Empty',
    //         'dough'=>2,
    //         'cheese'=>2,
    //         'sauce'=>2,
    //         'toppings'=>['1', '2'],
    //         'price'=>100,
    //         'image'=>'https://img.pizza/300/300'
    //     ]
    // ];

    $stmt = $dbc->prepare('SELECT * from tblPizza;');
    $result = $stmt->execute();

    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        if ($row['pizzaName'] === 'Custom Pizza') {
            continue;
        }

        $items[$row['pizzaID']] = [
            'name' => $row['pizzaName'],
            'description' => $row['description'],
            'price' => $row['pizzaPrice'],
            'image' => $row['imageurl']
        ];
    }
    return $items;
}

function getPizzaDataById($dbc, $pizzaID)
{
    $stmt = $dbc->prepare('SELECT * from tblPizza WHERE pizzaID=' . $pizzaID . ';');
    $result = $stmt->execute();

    $pizza = "";
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pizza = [
            'name' => $row['pizzaName'],
            'description' => $row['description'],
            'dough' => $row['doughCode'],
            'cheese' => $row['cheeseCode'],
            'sauce' => $row['sauceCode'],
            'toppings' => explode(',', $row['toppings']),
            'price' => $row['pizzaPrice'],
            'image' => $row['imageurl']
        ];
    }
    return $pizza;
}

function getDough($dbc)
{
    // $items=[
    //     '0'=>[
    //         'name'=>'thin',
    //         'price'=>100
    //     ],
    //     '1'=>[
    //         'name'=>'thick',
    //         'price'=>200
    //     ],
    //     '2'=>[
    //         'name'=>'hand tossed',
    //         'price'=>300
    //     ]
    // ];

    $stmt = $dbc->prepare('SELECT * from tblDough;');
    $result = $stmt->execute();

    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $items[$row['doughCode']] = [
            'name' => $row['doughName'],
            'price' => $row['doughPrice']
        ];
    }
    return $items;
}

function getCheese($dbc)
{
    // $items=[
    //     '0'=>[
    //         'name'=>'mozzarela',
    //         'price'=>100
    //     ],
    //     '1'=>[
    //         'name'=>'cheddar',
    //         'price'=>200
    //     ],
    //     '2'=>[
    //         'name'=>'parmesan',
    //         'price'=>300
    //     ]
    // ];

    $stmt = $dbc->prepare('SELECT * from tblCheese;');
    $result = $stmt->execute();

    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $items[$row['cheeseID']] = [
            'name' => $row['cheeseName'],
            'price' => $row['cheesePrice']
        ];
    }
    return $items;
}

function getSauce($dbc)
{
    // $items=[
    //     '0'=>[
    //         'name'=>'white',
    //         'price'=>100
    //     ],
    //     '1'=>[
    //         'name'=>'red',
    //         'price'=>200
    //     ]
    // ];

    $stmt = $dbc->prepare('SELECT * from tblSauce;');
    $result = $stmt->execute();

    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $items[$row['sauceID']] = [
            'name' => $row['sauceName'],
            'price' => $row['saucePrice']
        ];
    }
    return $items;
}

function getToppings($dbc)
{
    // $items=[
    //     '0'=>[
    //         'name'=>'pepperoni',
    //         'price'=>10
    //     ],
    //     '1'=>[
    //         'name'=>'beef',
    //         'price'=>20
    //     ],
    //     '2'=>[
    //         'name'=>'olive',
    //         'price'=>30
    //     ],
    //     '3'=>[
    //         'name'=>'green pepper',
    //         'price'=>40
    //     ],
    //     '4'=>[
    //         'name'=>'chicken',
    //         'price'=>50
    //     ]
    // ];

    $stmt = $dbc->prepare('SELECT * from tblToppings;');
    $result = $stmt->execute();

    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $items[$row['toppingCode']] = [
            'name' => $row['toppingName'],
            'price' => $row['toppingPrice']
        ];
    }
    return $items;
}

function saveOrder($dbc, $customerID, $deliveryType, $orderSummary)
{
    $menu = getPizzaMenu($dbc);
    $dough = getDough($dbc);
    $sauce = getSauce($dbc);
    $cheese = getCheese($dbc);
    $toppings = getToppings($dbc);


    //prepare data for orders table
    $date = date('Y-m-d');
    $time = date("H:i:s");

    $orderStatusCode = 1;


    if ($deliveryType === 'pickup') {
        $orderDeliveryType = "H";
    } else {
        $orderDeliveryType = "D";
    }

    //save and compute prices
    $orderFinalPrice = 0;
    foreach ($orderSummary as $orderSummaryKey => $order) {
        $unitPrice = 0;

        if ($order['type'] === 'custom') {

            $unitPrice += $menu[$order['detail']['pizzaID']]['price'];

            if (isset($order['detail']['toppings'])) {
                foreach ($order['detail']['toppings'] as $topping) {
                    $unitPrice += $toppings[$topping]['price'];
                }
            }

            //save unit prices
            $orderSummary[$orderSummaryKey]['unitPrice'] = $unitPrice;

            //compute total price
            $orderFinalPrice += $unitPrice;
        } else if ($order['type'] === 'create') {

            $unitPrice += $dough[$order['detail']['dough']]['price'];
            $unitPrice += $sauce[$order['detail']['sauce']]['price'];
            $unitPrice += $cheese[$order['detail']['cheese']]['price'];

            if (isset($order['detail']['toppings'])) {
                foreach ($order['detail']['toppings'] as $topping) {
                    $unitPrice += $toppings[$topping]['price'];
                }
            }

            //save unit prices
            $orderSummary[$orderSummaryKey]['unitPrice'] = $unitPrice;

            //compute total price
            $orderFinalPrice += $unitPrice;
        }
    }

    //logger('save orderSummary', $orderSummary);
    //logger('total price', $orderFinalPrice);

    //logger('menu', $menu);
    ////////////////////////////////////////////////////////////////////
    // Change. Taehyung Kim
    // Nov 4, 2020
    // change qry for prevent sql injection
    $field_data = array();
    $qry_ct = "insert into tblOrdersHeader set customerID= ?, orderDate= ?, orderTime= ?, orderStatusCode= ?, orderDeliveryType= ?, orderFinalPrice= ?";
    $field_data[] = $customerID;
    $field_data[] = $date;
    $field_data[] = $time;
    $field_data[] = $orderStatusCode;
    $field_data[] = $orderDeliveryType;
    $field_data[] = $orderFinalPrice;

    $stmt = $dbc->prepare($qry_ct);
    if (!$stmt) {
        echo "<p>Error in contact prepare: " . $dbc->errorCode() . "</p>\n<p>Message " . implode($dbc->errorInfo()) . "</p>\n";
        exit(1);
    }
    $result = $stmt->execute($field_data);
    unset($stmt);
    unset($field_data);
    unset($qry_ct);

    $orderID = $dbc->lastInsertId();

    //logger('tblOrdersHeader sql', $sql);
    //var_dump($result);

    //add orders to tblOrdersDetail
    foreach ($orderSummary as $order) {
        $pizzaID = 'NULL';
        $doughCode = 'NULL';
        $sauceCode = 'NULL';
        $cheeseCode = 'NULL';
        $topping = 'NULL';
        $unitPrice = $order['unitPrice'];

        if ($order['type'] === 'custom') {
            $pizzaID = $order['detail']['pizzaID'];

            ////////////////////////////////////////////////////////////////////
            // Add. Taehyung Kim
            // Nov 4, 2020
            // For insert dough, sauce, cheese, toppings. in case of custom(fix) pizza.
            $temp_pizza = getPizzaDataById(connectDB(), $pizzaID);

            $doughCode = $temp_pizza['dough'];
            $sauceCode = $temp_pizza['sauce'];
            $cheeseCode = $temp_pizza['cheese'];
            $topping =  implode(',', $temp_pizza['toppings']);
            //$topping = "\"" . implode(',', $temp_pizza['toppings']) . "\"";

            if (isset($order['detail']['toppings'])) {
                //$topping = substr($topping, 0, -1);
                $topping = $topping . "," . implode(',', $order['detail']['toppings']);
            }
        } else if ($order['type'] === 'create') {
            $doughCode = $order['detail']['dough'];
            $sauceCode = $order['detail']['sauce'];
            $cheeseCode = $order['detail']['cheese'];

            if (isset($order['detail']['toppings'])) {
                $topping = implode(',', $order['detail']['toppings']);
                //$topping = "\"" . implode(',', $order['detail']['toppings']) . "\"";
            }
        }

        ////////////////////////////////////////////////////////////////////
        // Change. Taehyung Kim
        // Nov 4, 2020
        // change qry fot prevent sql injection
        $field_data = array();
        $qry_ct = "insert into tblOrdersDetail set orderID= ?, pizzaID= ?, doughCode= ?, sauceCode= ?, cheeseCode= ?, topping= ?, unitPrice= ?";
        $field_data[] = $orderID;
        $field_data[] = $pizzaID;
        $field_data[] = $doughCode;
        $field_data[] = $sauceCode;
        $field_data[] = $cheeseCode;
        $field_data[] = $topping;
        $field_data[] = $unitPrice;

        $stmt = $dbc->prepare($qry_ct);
        if (!$stmt) {
            echo "<p>Error in contact prepare: " . $dbc->errorCode() . "</p>\n<p>Message " . implode($dbc->errorInfo()) . "</p>\n";
            exit(1);
        }
        $result = $stmt->execute($field_data);

        unset($stmt);
        unset($field_data);
        unset($qry_ct);
    }

    return $result;
}

function getDeliveryDetails($dbc, $customerID)
{
    $sql = 'SELECT * FROM tblCustomers WHERE customerID=' . $customerID;

    $stmt = $dbc->prepare($sql);
    $result = $stmt->execute();

    $detail = array();
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $detail = [
            'address1' => $row['address1'],
            'address2' => $row['address2'],
            'city' => $row['city'],
            'province' => $row['province'],
            'postalcode' => $row['postalcode'],
        ];
    }
    return $detail;
}

function getCustomerInfo($dbc, $customerID)
{
    $sql = 'SELECT * FROM tblCustomers WHERE customerID=' . $customerID;


    $stmt = $dbc->prepare($sql);
    $result = $stmt->execute();

    $detail = array();
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $detail = [
            'email' => $row['email']
        ];
    }
    return $detail;
}

function getPreviousOrders($dbc, $customerID)
{
    //$sql = 'SELECT * FROM tblOrdersHeader WHERE customerID=' . $customerID . ' ORDER BY orderDate, orderTime DESC';
    $sql = 'SELECT * FROM tblOrdersHeader WHERE customerID=' . $customerID . ' ORDER BY orderID DESC';
    $stmt = $dbc->prepare($sql);
    $result = $stmt->execute();

    $previousOrders = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        //get order details
        $details = [];
        $sqlDetails = 'SELECT * FROM tblOrdersDetail WHERE orderID=' . $row['orderID'];
        $stmtDetails = $dbc->prepare($sqlDetails);
        $resultDetails = $stmtDetails->execute();

        while ($rowDetails = $stmtDetails->fetch(PDO::FETCH_ASSOC)) {
            $toppings = [];
            if (isset($rowDetails['topping'])) {
                $toppings = explode(',', $rowDetails['topping']);
            }

            $details[$rowDetails['orderDetailID']] = [
                'pizzaID' => $rowDetails['pizzaID'],
                'doughCode' => $rowDetails['doughCode'],
                'sauceCode' => $rowDetails['sauceCode'],
                'cheeseCode' => $rowDetails['cheeseCode'],
                'toppings' => $toppings,
                'price' => $rowDetails['unitPrice']
            ];
        }

        //build orders data
        $previousOrders[$row['orderID']] = [
            'date' => $row['orderDate'],
            'time' => $row['orderTime'],
            'status' => $row['orderStatusCode'],
            'type' => $row['orderDeliveryType'],
            'price' => $row['orderFinalPrice'],
            'detail' => $details
        ];
    }

    //logger('previous order', $previousOrders);

    return $previousOrders;
}

function getOrderStatusById($id)
{
    //  1:Ready(Ordered) 2:Processing 3:Complete 4:waitDelivery 5:onDelivery 6:endDelivery 7:waitHandover(in store) 8:endHandover 9: Canceled

    $status = [
        '1' => 'Ready(Ordered)',
        '2' => 'Processing',
        '3' => 'Complete',
        '4' => 'Wait Delivery',
        '5' => 'On Delivery',
        '6' => 'End Delivery',
        '7' => 'Wait Handover(In Store)',
        '8' => 'End Handover',
        '9' => 'Cancelled'
    ];

    return $status[$id];
}

function getDeliveryTypeByCode($code)
{
    //  H: handover D: Delivery

    if (strtolower($code) === 'd') {
        return 'Delivery';
    } else if (strtolower($code) === 'h') {
        return 'Pickup';
    }

    return '';
}

function getOrderDetailDataById($dbc, $id)
{
    $sql = 'SELECT * FROM tblOrdersDetail WHERE orderDetailID=' . $id;
    $stmt = $dbc->prepare($sql);
    $result = $stmt->execute();

    $order = array();
    if ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $type = 'create';
        $details = [];

        if (isset($row['pizzaID'])) {
            $type = 'custom';
            $details['pizzaID'] = $row['pizzaID'];
        } else {
            $details = [
                'dough' => $row['doughCode'],
                'sauce' => $row['sauceCode'],
                'cheese' => $row['cheeseCode']
            ];
        }

        if (isset($row['topping'])) {
            $toppings = explode(',', $row['topping']);
            $details['toppings'] = $toppings;
        }

        $order = [
            'type' => $type,
            'detail' => $details
        ];
    }

    return $order;
}

function destroySession()
{
    // remove all session variables
    session_unset();

    // destroy the session
    session_destroy();
}
