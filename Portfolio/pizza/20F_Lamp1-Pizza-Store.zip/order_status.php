<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body>
    <!-- Load navigationMenu -->
    <?php
    // table or oven
    header("refresh: 5;");
    $work_place = $_GET['place'];
    $order_status = "";
    if ($work_place == 'table') {
        $order_status = 1;
    } else if ($work_place == 'oven') {
        $order_status = 2;
    } else if ($work_place == 'prep') {
        $order_status = 3;
    }
    $recentOrder = recentOrderIDandDeliveryType();
    $recentOrderID = $recentOrder['orderID'];
    $recentOrderDeliveryType = $recentOrder['type'];
    //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . './order_workplace.php';

    function noOrderDisplay()
    { ?>
        <div class="clearfix"></div>
        <div style="margin-top: 10px;">
            <div>
                <div class="alert alert-warning" role="alert">No Order to display</div>
            </div>
        </div>
        <?php    }

    function loadOrderComleteList()
    {
        //1:Ready(Ordered) 2:Processing 3:Complete 4:waitDelivery 5:onDelivery 6:endDelivery 7:waitHandover(in store) 8:endHandover 9: Canceled
        global $db_conn;
        global $order_status;
        $qry = "select H.orderID, H.orderTime, count(D.orderID) as count from tblOrdersHeader as H 
        JOIN tblOrdersDetail as D on H.orderID = D.orderID
        WHERE H.orderStatusCode ='" . $order_status . "'
        GROUP BY H.orderID
        ORDER BY H.orderID ASC";
        $stmt = $db_conn->prepare($qry);
        if (!$stmt) {
            echo "<p>Error in display prepare: " . $db_conn->errorCode() . "</p>\n<p>Message " . implode($db_conn->errorInfo()) . "</p>\n";
            exit(1);
        }
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
        ?><div class="clearfix"></div>
                <div style="margin-top: 10px;">
                    <div class="alert alert-warning" role="alert">
                        <h2 style="text-align: center;"><?php if ($order_status == 1) {
                                                            echo "Order List";
                                                        } else if ($order_status == 2) {
                                                            echo "In the Oven";
                                                        } else if ($order_status == 3) {
                                                            echo "Need a Box";
                                                        } ?></h2>
                    </div>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col" style="text-align: center;">Order#</th>
                                <th scope="col">orderTime</th>
                                <th scope="col" style="text-align: center;">Qty</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <th scope="row" style="background-color: white;text-align: center;"><?php echo $row['orderID']; ?></th>
                                    <td style="background-color: white;"><?php echo $row['orderTime']; ?></td>
                                    <td style="background-color: white;text-align: center;"><?php echo $row['count']; ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

            <?php
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
    }
    function recentOrderIDandDeliveryType()
    {
        global $db_conn;
        global $order_status;
        // loading the first order id
        $qry = "select H.orderID as orderID, H.orderDeliveryType as type from tblOrdersHeader as H
                JOIN tblOrdersDetail as D on H.orderID = D.orderID
                WHERE orderStatusCode ='" . $order_status . "'
                ORDER BY orderID ASC
                LIMIT 1";
        $stmt = $db_conn->prepare($qry);
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return $row;
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
        unset($nowOrderID);
    }

    function loadPizzaRecipeByOrderID()
    {
        global $db_conn;
        global $recentOrderID;
        global $order_status;

        // There are 2 phase.
        // 1. insert array(select tblOrderDetail join dough, sauce, cheese without topping)
        // 2. topping update

        $qry = "select O.orderDetailID, D.doughName, S.sauceName, C.cheeseName, O.topping from tblOrdersDetail as O 
        join tblDough as D ON O.doughCode = D.doughCode 
        join tblSauce as S ON O.sauceCode = S.sauceID 
        join tblCheese as C ON O.cheeseCode = C.cheeseID 
        where O.orderID = " . $recentOrderID . "
        order by O.orderDetailID ASC;";
        $stmt = $db_conn->prepare($qry);
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) { ?>
                <div class="clearfix"></div>
                <div style="margin-top: 10px;">
                    <div class="alert alert-danger" style="margin-top: 10px;" role="alert">
                        <h2>Order Recipe</h2>
                    </div>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">OrderD#</th>
                                <th scope="col">Dough</th>
                                <th scope="col">Sauce</th>
                                <th scope="col">Cheese</th>
                                <th scope="col">Topping</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <th scope="row" style="background-color: white;text-align: center;"><?php echo $row['orderDetailID']; ?></th>
                                    <td style="background-color: white;"><?php echo $row['doughName']; ?></td>
                                    <td style="background-color: white;"><?php echo $row['sauceName']; ?></td>
                                    <td style="background-color: white;"><?php echo $row['cheeseName']; ?></td>
                                    <td style="background-color: white;">
                                        <?php $toppings = explode(',', $row['topping']);
                                        foreach ($toppings as &$toppingCode) {
                                            $to = getToppingName($toppingCode);
                                            echo ($to . "<br>");
                                        }
                                        unset($toppingCode);
                                        ?>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?></tbody>
                    </table>
                </div>
            <?php
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
    }

    function getToppingName($toppingId)
    {
        global $db_conn;
        $qry = "select toppingName from tblToppings 
        WHERE toppingCode ='" . $toppingId . "'";
        $stmt = $db_conn->prepare($qry);
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $toppingName = $row['toppingName'];
                return $toppingName;
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
    }

    function toBeProcessedOrdersAndPizza()
    {
        global $db_conn;
        global $order_status;
        $qry = "select count(DISTINCT H.orderID) as o, count(D.orderDetailID) as p from tblOrdersHeader as H join tblOrdersDetail as D ON H.orderID = D.orderID where H.orderStatusCode = '" . $order_status . "'";
        $stmt = $db_conn->prepare($qry);
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $numberOfOrder = $row['o'];
                $numberOfPizza = $row['p'];
            ?>
                <div class="clearfix"></div>
                <div style="margin-top: 10px;">
                    <div class="alert alert-warning" role="alert">
                        <h2 style="text-align: center;"><?php if ($order_status == 1) {
                                                            echo "Order Queue";
                                                        } else if ($order_status == 2) {
                                                            echo "Oven Queue";
                                                        } else if ($order_status == 3) {
                                                            echo "Boxing Queue";
                                                        } ?></h2>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class="alert alert-secondary" role="alert">
                                    <h3 style="text-align: center;">Order</h3>
                                </div>
                            </div>
                            <div class="col">
                                <div class="alert alert-danger" role="alert">
                                    <h3 style="text-align: center;">Pizza</h3>
                                </div>
                            </div>
                            <div class="w-100"></div>
                            <div class="col">
                                <div class="alert alert-secondary" role="alert">
                                    <h3 style="text-align: center;"><?php echo $numberOfOrder; ?></h3>
                                </div>
                            </div>
                            <div class="col">
                                <div class="alert alert-danger" role="alert">
                                    <h3 style="text-align: center;"><?php echo $numberOfPizza; ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        <?php
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
    }
    //Page Load
    if (isset($_POST['next'])) {
        // order status change here.
        // Array
        // (
        //     [next] => 57
        // )
        orderStatusChange($_POST['next']);
    }

    function orderStatusChange($orderID)
    {
        global $db_conn;
        global $order_status;
        global $work_place;
        global $recentOrderDeliveryType; //	H: handover D: Delivery

        $field_data = array();
        $qry_ct = "update tblOrdersHeader set orderStatusCode =? ";
        if ($order_status == '1') {
            $field_data[] = 2;
            $qry_ct = $qry_ct . ", startOvenTime =? ";
        } else if ($order_status == '2') {
            $field_data[] = 3;
            $qry_ct = $qry_ct . ", endOvenTime =? ";
        } else if ($order_status == '3') {
            if ($recentOrderDeliveryType == 'H') {
                $field_data[] = 7;
            } else if ($recentOrderDeliveryType == 'D') {
                $field_data[] = 5;
            }
            $qry_ct = $qry_ct . ", inBoxTime =? ";
        }
        //$curTime = date_create();
        //$curTime = NULL;
        $field_data[] = date("Y-m-d H:i:s");
        $qry_ct = $qry_ct . "where orderID='" . $orderID . "'";

        $stmt = $db_conn->prepare($qry_ct);
        if (!$stmt) {
            echo "<p>Error in contact prepare: " . $db_conn->errorCode() . "</p>\n<p>Message " . implode($db_conn->errorInfo()) . "</p>\n";
            exit(1);
        }
        $status = $stmt->execute($field_data);
        if (!$status) {
            echo "Error " . $stmt->errorCode() . "\nMessage " . implode($stmt->errorInfo()) . "\n";
            exit(1);
        }

        unset($stmt);
        unset($field_data);
        unset($qry_ct);
        unset($status);
        unset($_POST['next']);

        header('Location: ./order_status.php?place=' . $work_place);
    }

    function calculateOvenTime()
    {
        global $db_conn;
        global $recentOrderID;
        global $order_status;
        // load oven start time
        // loading the first order id
        $qry = "select H.startOvenTime from tblOrdersHeader as H
        JOIN tblOrdersDetail as D on H.orderID = D.orderID
        WHERE orderStatusCode ='" . $order_status . "' and H.orderID = " . $recentOrderID . "
        LIMIT 1";
        $stmt = $db_conn->prepare($qry);
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $startOvenTime = $row['startOvenTime'];
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
        // current time
        $curTime = strtotime(date("Y-m-d H:i:s"));

        $startOvenTime = strtotime($startOvenTime);

        $proTime = $curTime - $startOvenTime;
        ?>
        <div class="clearfix"></div>
        <div style="margin-top: 10px;">
            <div class="alert alert-danger" style="margin-top: 10px;" role="alert">
                <h2>Time in the oven</h2>
            </div>
            <div style="text-align: center;">
                <h1 class="display-1"><?php echo date("i:s", $proTime); ?></h1>
            </div>
        </div>
    <?php
    }
    ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col" style="background-color:darkslateblue">

                <?php
                // completed order list up
                loadOrderComleteList();
                ?>
            </div>
            <div class="col-6">


                <?php
                if ($work_place == 'table' && $recentOrderID != "") {
                    // pizza recipe by orderID
                    loadPizzaRecipeByOrderID();
                } else if ($work_place == 'oven' && $recentOrderID != "") {
                    calculateOvenTime();
                } else if ($work_place == 'prep' && $recentOrderID != "") {
                    //show the delevery type
                    if ($recentOrderDeliveryType == "D") {
                        $type = "Delevery!";
                    } else if ($recentOrderDeliveryType == "H") {
                        $type = "Pick Up!";
                    }
                ?>
                    <h1 class="display-1">
                        <?php echo "Order#" . $recentOrderID . " is " . $type; ?>
                    </h1>
                <?php
                }
                ?>
            </div>
            <div class="col" style="background-color:darkslateblue">



                <?php
                // Orders to be processed &
                toBeProcessedOrdersAndPizza();
                // 1:Ready(Ordered)->2:Processing
                // 2:Processing->3:Complete
                ?><div style="margin-bottom: 10px;">
                    <form method="POST">
                        <button type="submit" name="next" value='<?php echo $recentOrderID ?>' class="btn btn-primary btn-lg btn-block">Order#<?php echo $recentOrderID ?> Complete!</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="./js/bootstrap/popper.min.js"></script>
    <script src="./js/bootstrap/bootstrap.min.js"></script>
</body>

</html>