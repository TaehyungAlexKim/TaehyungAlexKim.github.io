<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="./index.php">
        <img src="https://getbootstrap.com/docs/4.5/assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt="#" loading="lazy">
        Group2 Pizza Store
    </a>
    <!-- <a class="navbar-brand" href="#">Group2 Pizza Store</a> -->
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Start Menu -->
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="./index.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="./usermain.php">User Info </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Admin
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="./order_mornitoring.php">Mornitoring</a>
                    <a class="dropdown-item" href="./order_status.php?place=table">Status</a>
                </div>
            </li>
            <?php if (isset($_SESSION['customerEmail'])) { ?>
                <li class="nav-item active">
                    <a class="nav-link" href="./destroysession.php">Logout </a>
                </li>
            <?php } ?>
            <!-- <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
      </li> -->
        </ul>
        <span class="mr-sm-2 text-white bg-dark">Welcome
            <?php if (isset($_SESSION['customerName'])) {
                echo $_SESSION['customerName'];
            } ?>
            !</span>
    </div>
    <!-- End Menu -->
</nav>