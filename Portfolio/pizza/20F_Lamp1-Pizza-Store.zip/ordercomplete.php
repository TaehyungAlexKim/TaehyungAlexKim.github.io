<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

	<link rel="stylesheet" href="./css/style.css">

	<?php
	define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
	include _SERVER_PATH_ . 'common.php';
	$db_conn = connectDB();
	?>

	<title>Group2 - Pizza store</title>
</head>

<body>
	<!-- Load navigationMenu -->

	<?php
	//define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
	include _SERVER_PATH_ . 'navigationMenuOrderComplete.php';
	?>

	<div class="container-md">
		<?php
		//logger('Post', $_POST);
		//logger('Session', $_SESSION); 
		if (isset($_POST['home'])) {

		?><script>
				location.href = './index.php';
			</script><?php
					}
						?>

		<?php if (!isset($_SESSION['customerID'])) { ?>
			<p class="error">No customer information for this order. Please try again.</p>
			<a href="./">Home</a>
		<?php } else if (!isset($_SESSION['orderSummary'])) { ?>
			<p class="error">No orders placed. Please try again.</p>
			<a href="./">Home</a>
			<?php } else {

			$result = saveOrder($db_conn, $_SESSION['customerID'], $_POST['deliveryType'], $_SESSION['orderSummary']);

			if ($result === false) { ?>
				<p class="error">There was an error in processing your order. Please try again.</p>
				<a href="./">Home</a>
			<?php } else { ?>

				<div class="order-complete">
					<div class="order-complete-inner">
						<h2>Order Complete</h2>

						<?php $customerInfo = getCustomerInfo($db_conn, $_SESSION['customerID']); ?>

						<?php if ($_POST['deliveryType'] === 'delivery') { ?>

							<p>
								Pizza will be ready for delivery in 40 minutes.
							</p>

							<?php include _SERVER_PATH_ . 'deliverydetails.php'; ?>

						<?php } else if ($_POST['deliveryType'] === 'pickup') { ?>
							<p>
								Pizza will be ready for pickup in 40 minutes.
							</p>
						<?php }
						?>
						<div class="customer-info">
							<h3>Customer Info</h3>
							<p><?= $customerInfo['email']; ?></p>
						</div>
						<?php include _SERVER_PATH_ . 'summary.php';
						////////////////////////////////////////////////////////////////////
						// Change. Taehyung Kim
						// Nov 6, 2020
						// change: destroy all Session except customer ID
						unset($_SESSION['orderSummary']);
						?>

						<form method="POST">
							<button name="home" type="submit" class="btn btn-primary">Home</button>
						</form>
					</div>


				</div>
			<?php
			}


			?>

		<?php
		} ?>
	</div>


</body>

</html>