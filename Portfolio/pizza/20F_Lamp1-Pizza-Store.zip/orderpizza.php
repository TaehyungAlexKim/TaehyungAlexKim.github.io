<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">


    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body>
    <!-- Load navigationMenu -->
    <?php
    //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'navigationMenu.php';
    ?>

    <div class="container-xl">
        <?php
        //logger('Session', $_SESSION);

        //if customerID is not set in session then show error
        if (!isset($_SESSION['customerID'])) { ?>
            <p class="error">No customer information for this order. Please try again.</p>
            <a href="./">Home</a>
        <?php } else {
            $menu = getPizzaMenu($db_conn);
        ?>
            <div class="shadow p-3 mb-5 bg-white rounded" style="margin-top: 20px;">
                <h1 class="display-4" style="margin-bottom: 20px;">Here is your Pizza Menu!</h1>
                <div class="row row-cols-3">
                    <div class="col-lg">
                        <div class="card" style="width: 20rem; margin-bottom:10px;">
                            <img class="card-img-top" src="img/create.jpeg">
                            <div class="card-body">
                                <h5 class="card-title">Create Pizza</h5>
                                <p class="card-text">Make your Pizza!</p>
                                <a href="orderpizzadetail.php?pizza-id=-1&create=y" class="btn btn-primary stretched-link">Customize</a>
                            </div>
                        </div>
                    </div>
                    <?php
                    foreach ($menu as $key => $item) {
                    ?>
                        <div class="col-lg">
                            <div class="card" style="width: 20rem; margin-bottom:10px;">
                                <img class="card-img-top" src="img/<?= $item['image']; ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?= $item['name']; ?></h5>
                                    <p class="card-text"><?= $item['description']; ?></p>
                                    <p class="card-text">$<?= $item['price']; ?></p>
                                    <a href="orderpizzadetail.php?pizza-id=<?= $key; ?>&create=n" class="btn btn-primary stretched-link">Customize</a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                </div>
            </div>
        <?php } ?>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="./js/bootstrap/popper.min.js"></script>
    <script src="./js/bootstrap/bootstrap.min.js"></script>
</body>

</html>