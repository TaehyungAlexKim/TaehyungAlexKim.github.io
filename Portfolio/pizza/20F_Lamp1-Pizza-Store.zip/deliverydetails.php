<?php $deliveryDetails=getDeliveryDetails( $db_conn, $_SESSION['customerID'] ); ?>
<div class="delivery-details">
	<h3>Delivery Details</h3>
	<div class="delivery-row">
		<p>Address:</p>
		<p>
				<span><?= $deliveryDetails['address1']; ?></span>
				<span><?= $deliveryDetails['address2']; ?></span>
				<span><?= $deliveryDetails['city']; ?></span>
				<span><?= $deliveryDetails['province']; ?></span>
				<span><?= $deliveryDetails['postalcode']; ?></span>
			</p>
	</div>
</div>