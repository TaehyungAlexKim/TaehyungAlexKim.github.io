<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

    <link rel="stylesheet" href="./css/style.css">

    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body>
    <!-- Load navigationMenu -->
    <?php
    //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'navigationMenu.php';
    ?>

    <div class="container-md">
        <?php
        //logger('Session', $_SESSION); 
        ?>

        <?php if (!isset($_SESSION['customerID'])) { ?>
            <p class="error">No customer information. Please try again.</p>
            <a href="./">Home</a>
        <?php } else {

            $previousOrders = getPreviousOrders($db_conn, $_SESSION['customerID']);
            $menu = getPizzaMenu($db_conn);
            $dough = getDough($db_conn);
            $sauce = getSauce($db_conn);
            $cheese = getCheese($db_conn);
            $toppings = getToppings($db_conn); ?>
            <form action="processpizzaorder.php" method="POST">
                <div class="previous-orders">
                    <h2>Order History <em>* Current prices may have been updated</em></h2>
                    <ul>
                        <?php foreach ($previousOrders as $order) { ?>
                            <li>
                                <p>Date Ordered: <?= $order['date']; ?> <?= $order['time']; ?></p>
                                <p>Order Status: <?= getOrderStatusById($order['status']); ?></p>
                                <p>Delivery Type: <?= getDeliveryTypeByCode($order['type']); ?></p>
                                <p>Total Price: $<?= $order['price']; ?></p>
                                <ul class="previous-detail">
                                    <?php foreach ($order['detail'] as $detailID => $detail) { ?>
                                        <li>
                                            <div class="previous-item">
                                                <div>
                                                    <button class="button" type="submit" name="submit" value="reorder-<?= $detailID; ?>">Order Again</button>
                                                </div>
                                                <div>
                                                    <?php
                                                    //changed by taehyung "isset" not works
                                                    if (!empty($detail['pizzaID'])) { ?>

                                                        <img src="img/<?= $menu[$detail['pizzaID']]['image']; ?>">
                                                    <?php } else { ?>
                                                        <div class="no-image"></div>
                                                    <?php } ?>
                                                </div>
                                                <div>
                                                    <div class="delivery-row">
                                                        <?php
                                                        //changed by taehyung "isset" not works 
                                                        if (!empty($detail['pizzaID'])) { ?>
                                                            <p><?= $menu[$detail['pizzaID']]['name']; ?></p>
                                                        <?php } else { ?>
                                                            <p>Created Pizza</p>
                                                        <?php } ?>

                                                        <p>$<?= $detail['price']; ?></p>
                                                    </div>

                                                    <?php
                                                    //changed by taehyung "isset" not works
                                                    if (empty($detail['pizzaID'])) { ?>
                                                        <p class="ingredients">
                                                            <span>Dough: <?= $dough[$detail['doughCode']]['name']; ?></span>
                                                            <span>Sauce: <?= $sauce[$detail['sauceCode']]['name']; ?></span>
                                                            <span>Cheese: <?= $cheese[$detail['cheeseCode']]['name']; ?></span>
                                                        </p>
                                                    <?php } ?>

                                                    <?php
                                                    if (isset($detail['toppings']) && count($detail['toppings']) > 0) { ?>
                                                        <p class="ingredients">
                                                            <?php if (isset($detail['pizzaID'])) {
                                                                echo 'additional';
                                                            } ?>
                                                            toppings:

                                                            <?php foreach ($detail['toppings'] as $topping) { ?>
                                                                <span><?= $toppings[$topping]['name']; ?></span>
                                                            <?php } ?>
                                                        </p>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </li>
                                    <?php
                                    } ?>
                                </ul>
                            </li>
                        <?php } ?>
                    </ul>
                </div>
            </form>
        <?php
        } ?>
    </div>
</body>

</html>