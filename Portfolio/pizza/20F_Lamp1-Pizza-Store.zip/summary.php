<div class="summary">
	<h2>Order Summary</h2>
	<ul>
		<?php

		$dough=getDough($db_conn);
	$sauce=getSauce($db_conn);
	$cheese=getCheese($db_conn);
		$toppings=getToppings($db_conn);
		$total=0;

		//loop each order data
		foreach($_SESSION['orderSummary'] as $key=>$order) { ?>
			<li>
				<div>	    						
					<?php 
						//if custom pizza order
						if( $order['type'] === 'custom' ) { 
							$pizza=getPizzaDataById($db_conn, $order['detail']['pizzaID']); 
							//logger('Pizza', $pizza); 

							$total+=$pizza['price'];?>

							<div class="order-row">
								<p><?= ($key + 1) . '.'; ?></p>
								<p><?= $pizza['name']; ?></p>
								<p>$<?= $pizza['price']; ?></p>
							</div>

							<?php 
							//if there are additional toppings for custom pizza
							if( isset($order['detail']['toppings']) ) { ?>
								<div class="additional">
									<p>Additional Toppings:</p>
    								<ul>
    									<?php
    									foreach($order['detail']['toppings'] as $topping) { 
    										$total+=$toppings[$topping]['price']; ?>
	    									<li>
	    										<div class="topping-row">
	    											<p><?= $toppings[$topping]['name'] ;?></p>
	    											<p>$<?= $toppings[$topping]['price'] ;?></p>
	    										</div>
	    									</li>
										<?php
										} ?>
    								</ul>
								</div>
								<?php 
								} ?>
					<?php 
						} elseif( $order['type'] === 'create' ) { ?>

								<div class="order-row">
								<p><?= ($key + 1) . '.'; ?></p>
								<p>Created Pizza</p>
								<p></p>
							</div>

							<div class="additional">

								<?php $total+=$dough[ $order['detail']['dough'] ]['price']; ?>
								<div class="order-row">
									<p>Dough: </p>
									<p><?= $dough[ $order['detail']['dough'] ]['name']; ?></p>
									<p>$<?= $dough[ $order['detail']['dough'] ]['price']; ?></p>
								</div>

								<?php $total+=$sauce[ $order['detail']['sauce'] ]['price']; ?>
								<div class="order-row">
									<p>Sauce: </p>
									<p><?= $sauce[ $order['detail']['sauce'] ]['name']; ?></p>
									<p>$<?= $sauce[ $order['detail']['sauce'] ]['price']; ?></p>
								</div>

								<?php $total+=$cheese[ $order['detail']['cheese'] ]['price']; ?>
								<div class="order-row">
									<p>Cheese: </p>
									<p><?= $cheese[ $order['detail']['cheese'] ]['name']; ?></p>
									<p>$<?= $cheese[ $order['detail']['cheese'] ]['price']; ?></p>
								</div>

								<?php if( isset($order['detail']['toppings']) ){ ?>
									<p>Toppings:</p>
    								<ul>
    									<?php
    									foreach( $order['detail']['toppings'] as $topping) { 
    										$total+=$toppings[$topping]['price']; ?>
	    									<li>
	    										<div class="topping-row">
	    											<p><?= $toppings[$topping]['name']; ?></p>
	    											<p>$<?= $toppings[$topping]['price']; ?></p>
	    										</div>
	    									</li>
										<?php
										} ?>
    								</ul>
								<?php 
								} ?>
								
							</div>

						<?php 
						} ?>

				</div>
			</li>
		<?php } ?>
	</ul>
	<div class="total-row">
		<p>Total</p>
		<p>$<?= number_format($total, 2); ?></p>
	</div>
</div>