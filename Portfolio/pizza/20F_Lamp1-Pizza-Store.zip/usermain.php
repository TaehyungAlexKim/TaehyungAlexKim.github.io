<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body>
    <!-- Load navigationMenu -->
    <?php
    //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'navigationMenu.php';
    function validation($arg)
    {
        $result = array();
        if (!isset($arg['email']) || strlen($arg['email']) > 20 || $arg['email'] == "") {
            $result['email'] = 'email';
        }
        if (!isset($arg['address1']) || strlen($arg['address1']) > 150 || $arg['address1'] == "") {
            $result['address1'] = 'address1';
        }
        if (!isset($arg['city']) || strlen($arg['city']) > 50 || $arg['city'] == "") {
            $result['city'] = 'city';
        }
        if (!isset($arg['postalcode']) || strlen($arg['postalcode']) > 10 || $arg['postalcode'] == "") {
            $result['postalcode'] = 'postalcode';
        }
        if (isset($arg['address2']) && strlen($arg['address2']) > 150) {
            $result['address2'] = 'address2';
        }
        if (isset($arg['customerName']) && strlen($arg['customerName']) > 30) {
            $result['customerName'] = 'customerName';
        }
        return $result;
    }

    // page load 
    // after submit

    $field_data = sanitize_html($_POST);

    if (isset($_SESSION['customerEmail'])) {
        // exist user
        $customerID = show_customer_information($db_conn, $_SESSION['customerEmail']);
        $_SESSION['customerID'] = $customerID;
        orderNow();
    } else if (!isset($_SESSION['customerEmail']) && isset($_SESSION['customerEmail_temp'])) {
        //for join
        if (count($field_data) > 2 && isset($_SESSION['customerEmail_temp'])) {
            // Validation check
            $val_result = validation($field_data);
            if (count($val_result) > 0) {
                // Re-Display with vaildation
                formJoin();
            } else {
                // insert customer data here
                create_user($db_conn, $field_data);
                getCustomerName($db_conn, $field_data['email']);
                header('Location: ./usermain.php');
                if ($result === false) {
                    echo " <p class=\"error\">There was an error in processing your order. Please try again.</p>";
                    echo " <a href=\"./\">Home</a>";
                } else {
                    // Display a confirmation message
                    echo "<div class=\"container-md\">";
                    echo "<br>";
                    echo "<div class=\"alert alert-success\" role=\"alert\">
                        Your entry was successfully inserted!
                        </div></div>";
                    //formCustomerInformation();
                    $_SESSION['customerEmail'] = $field_data['email'];

                    $customerID = show_customer_information($db_conn, $_SESSION['customerEmail']);
                    $_SESSION['customerID'] = $customerID;

                    //save customer id to session

                    orderNow();
                }
            }
        } else {
            formJoin();
        }
    } else {
        // No submit and No Session -> index.php
        header('Location: ./index.php');
    }

    function orderNow()
    {
        echo '<div class="container-md">';
        echo '<form action="./orderpizza.php" method="POST">';
        echo '<div class="d-flex justify-content-center"><div class=\"p-4\">';
        echo '<a class="btn btn-primary mr-2" href="previousorders.php">Previous Orders</a>';
        echo '<button type="submit" name="submit" class="btn btn-primary" value="submit">Begin</button></div></div>';
        echo '</form>';
        echo '</div>';
    }
    function formJoin()
    {

        $field_data = sanitize_html($_POST);

    ?>
        <div class="container-md">
            <h1>Create New Customer</h1>
            <form method="POST">
                <div class="form-group">
                    <label for="InputEmailAddress">This is Your Email address</label>
                    <input type="email" name="email" class="form-control" id="InputEmailAddress" aria-describedby="emailHelp" value="<?php echo $_SESSION['customerEmail_temp'] ?>" readonly>
                    <small id="emailHelp" class="form-text text-muted">We\'ll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="inputAddress">Customer Name</label>
                    <input name="customerName" type="text" class="form-control<?php if (count($field_data) > 2 && $field_data['customerName'] == "") {
                                                                                    echo ' is-invalid" Placeholder="Please insert name"';
                                                                                } else if (count($field_data) > 2 && strlen($field_data['customerName']) > 150) {
                                                                                    echo ' is-invalid" Placeholder="Name is too long(Maximun: 30 digits)"';
                                                                                } else {
                                                                                    echo ' placeholder="Alex Kim"';
                                                                                } ?>" id="inputAddress" <?php if (count($field_data) > 2 && $field_data['customerName'] != "") {
                                                                                                            echo ' value=' . $field_data['customerName'];
                                                                                                        } ?>>
                </div>
                <div class="form-group">
                    <label for="inputAddress">Address</label>
                    <input name="address1" type="text" class="form-control<?php if (count($field_data) > 2 && $field_data['address1'] == "") {
                                                                                echo ' is-invalid" Placeholder="Please insert address1"';
                                                                            } else if (count($field_data) > 2 && strlen($field_data['address1']) > 150) {
                                                                                echo ' is-invalid" Placeholder="Address1 is too long(Maximun: 150 digits)"';
                                                                            } else {
                                                                                echo ' placeholder="1234 Main St"';
                                                                            } ?>" id="inputAddress" <?php if (count($field_data) > 2 && $field_data['address1'] != "") {
                                                                                                        echo ' value=' . $field_data['address1'];
                                                                                                    } ?>>
                </div>
                <div class="form-group">
                    <label for="inputAddress2">Address 2</label>
                    <input name="address2" type="text" class="form-control<?php if (count($field_data) > 2 && strlen($field_data['address2']) > 150) {
                                                                                echo ' is-invalid" Placeholder="Address2 is too long(Maximun: 150 digits)"';
                                                                            } ?>" id="inputAddress2" <?php if (count($field_data) > 2 && $field_data['address2'] != "" && strlen($field_data['address2']) <= 150) {
                                                                                                            echo ' value=' . $field_data['address2'];
                                                                                                        } ?> placeholder="Apartment, studio, or floor">
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputCity">City</label>
                        <input name="city" type="text" class="form-control<?php if (count($field_data) > 2 && $field_data['city'] == "") {
                                                                                echo ' is-invalid" Placeholder="Please insert city"';
                                                                            } else if (count($field_data) > 2 && strlen($field_data['city']) > 50) {
                                                                                echo ' is-invalid" Placeholder="city is too long(Maximun: 50 digits)"';
                                                                            } ?>" id="inputCity" <?php if (count($field_data) > 2 && $field_data['city'] != "") {
                                                                                                        echo ' value=' . $field_data['city'];
                                                                                                    } ?>>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputState">Province</label>
                        <select name="province" id="inputState" class="form-control">
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "ON") {
                                        echo ' selected';
                                    } else if (count($field_data) == 2) {
                                        echo ' selected';
                                    } ?>>ON</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "QC") {
                                        echo ' selected';
                                    } ?>>QC</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "NS") {
                                        echo ' selected';
                                    } ?>>NS</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "NB") {
                                        echo ' selected';
                                    } ?>>NB</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "MB") {
                                        echo ' selected';
                                    } ?>>MB</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "BC") {
                                        echo ' selected';
                                    } ?>>BC</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "PE") {
                                        echo ' selected';
                                    } ?>>PE</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "SK") {
                                        echo ' selected';
                                    } ?>>SK</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "AB") {
                                        echo ' selected';
                                    } ?>>AB</option>
                            <option <?php if (count($field_data) > 2 && $field_data['province'] == "NL") {
                                        echo ' selected';
                                    } ?>>NL</option>
                        </select>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="inputZip">Postal Code(A9A 9A9)</label>
                        <input name="postalcode" type="text" class="form-control<?php if (count($field_data) > 2 && $field_data['postalcode'] == "") {
                                                                                    echo ' is-invalid" Placeholder="Please insert postalcode"';
                                                                                } else if (count($field_data) > 2 && strlen($field_data['postalcode']) > 10) {
                                                                                    echo ' is-invalid" Placeholder="postalcode is too long(Maximun: 10 digits)"';
                                                                                } ?>" id="inputZip" <?php if (count($field_data) > 2 && $field_data['postalcode'] != "") {
                                                                                                        echo ' value=' . $field_data['postalcode'];
                                                                                                    } ?>>
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-primary" value="submit">Submit</button>
            </form>
        </div>

    <?php
        //End function formJoin
    }
    // This bracket is the First bracket behind body tag    
    ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="./js/bootstrap/popper.min.js"></script>
    <script src="./js/bootstrap/bootstrap.min.js"></script>
</body>

</html>