<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

  <?php
  define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
  include _SERVER_PATH_ . 'common.php';
  $db_conn = connectDB();
  ?>

  <title>Group2 - Pizza store</title>
</head>

<body>
  <!-- Load navigationMenu -->
  <?php
  //define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
  include _SERVER_PATH_ . 'navigationMenu.php';
  ?>

  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="./img/banner1.jpg" class="d-block w-100" alt="..." height="400">
        <div class="carousel-caption d-none d-md-block">
          <h5>First slide label</h5>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./img/banner2.jpg" class="d-block w-100" alt="..." height="400">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="./img/banner3.jpg" class="d-block w-100" alt="..." height="400">
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <br>

  <?php
  $field_data = sanitize_html($_POST);
  // 1. if it has $_post submit -> check validation
  if (isset($field_data['submit'])) {
    $val_result = validationEmail($field_data);
    if (count($val_result) > 0) {
      // 1-2. invalid -> joinform again
      emailForm();
    } else {
      // 1-1. valid -> userinformation
      if (check_user($db_conn, $field_data) == 1) {
        // 1-1-1. if exist user, add session, page -> usermain.
        $_SESSION['customerEmail'] = $field_data['email'];
        getCustomerName($db_conn, $_SESSION['customerEmail']);
  ?>
        <script>
          location.href = './usermain.php';
        </script>
      <?php
      } else {
        // 1-1-2. if not exist user, add temp session, page -> usermain
        $_SESSION['customerEmail_temp'] = $field_data['email'];
      ?>
        <script>
          location.href = './usermain.php';
        </script>
    <?php
      }
    }
  } else if (isset($_SESSION['customerID'])) {
    ?>
    <script>
      location.href = './usermain.php';
    </script>
  <?php
  } else {
    // NEW customer
    emailForm();
  }


  function validationEmail($arg)
  {
    $result = array();
    if (!isset($arg['email']) || strlen($arg['email']) > 80 || $arg['email'] == "") {
      $result['email'] = 'email';
    }
    return $result;
  }

  function emailForm()
  {
    global $field_data;
  ?>
    <div class="container-md">
      <form method="POST">
        <div class="form-group">
          <label for="InputEmailAddress">Please Insert Your Email address</label>
          <input type="email" name="email" class="form-control <?php if (isset($field_data['submit']) && $field_data['email'] == "") {
                                                                  echo ' is-invalid" Placeholder="Please insert Email address"';
                                                                } else if (isset($field_data['submit']) && strlen($field_data['email']) > 80) {
                                                                  echo ' is-invalid" Placeholder="Email Address is too long(Maximun: 80 digits)"';
                                                                } ?>" id="InputEmailAddress" aria-describedby="emailHelp">
          <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
        </div>
        <button type="submit" name="submit" class="btn btn-primary" value="submit">Submit</button>
      </form>
    </div>
  <?php
  }

  ?>
  <!-- User Check -->



  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="./js/bootstrap/jquery-3.5.1.slim.min.js"></script>
  <script src="./js/bootstrap/popper.min.js"></script>
  <script src="./js/bootstrap/bootstrap.min.js"></script>
</body>

</html>