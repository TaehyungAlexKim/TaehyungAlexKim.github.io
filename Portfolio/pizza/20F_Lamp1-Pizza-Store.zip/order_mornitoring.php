<?php session_start(); ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css">

    <?php
    define('_SERVER_PATH_', str_replace(basename(__FILE__), "", realpath(__FILE__)));
    include _SERVER_PATH_ . 'common.php';
    $db_conn = connectDB();
    ?>

    <title>Group2 - Pizza store</title>
</head>

<body style="background-color: #646496;">
    <?php
    header("refresh: 5;");


    // email, order number, qty, status for Pick up
    function monitoring()
    {
        global $db_conn;

        $qry = "select H.orderID as orderID, C.email as email, count(D.orderID) as qty, H.orderStatusCode as status 
        from tblOrdersHeader as H 
                JOIN tblOrdersDetail as D on H.orderID = D.orderID
                JOIN tblCustomers as C on C.customerID = H.customerID
                WHERE H.orderDeliveryType = 'H'
                GROUP BY H.orderID
                ORDER BY H.orderID ASC";
        $stmt = $db_conn->prepare($qry);
        if (!$stmt) {
            echo "<p>Error in display prepare: " . $db_conn->errorCode() . "</p>\n<p>Message " . implode($db_conn->errorInfo()) . "</p>\n";
            exit(1);
        }
        $status = $stmt->execute();
        if ($status) {
            if ($stmt->rowCount() > 0) {
    ?><div class="clearfix"></div>
                <div style="margin-top: 10px;">
                    <div class="alert alert-warning" role="alert">
                        <h1 class="display-1" style="text-align: center;">Now Your Pizza is</h2>
                    </div>
                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col" style="text-align: center;">Order#</th>
                                <th scope="col">Email</th>
                                <th scope="col" style="text-align: center;">Qty</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
                                <tr>
                                    <th scope="row" style="background-color: white;text-align: center;">
                                        <h1><?php echo $row['orderID']; ?></h1>
                                    </th>
                                    <td style="background-color: white;">
                                        <h1><?php echo $row['email']; ?></h1>
                                    </td>
                                    <td style="background-color: white;text-align: center;">
                                        <h1><?php echo $row['qty']; ?></h1>
                                    </td>
                                    <td style="background-color: white;">
                                        <h1><?php
                                            if ($row['status'] == 1) {
                                                echo "Put up the topping";
                                            } else if ($row['status'] == 2) {
                                                echo "Baking";
                                            } else if ($row['status'] == 3) {
                                                echo "Ready fot Pick up";
                                            } ?></h1>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>

    <?php
            } else {
                noOrderDisplay();
            }
        } else {
            echo "<p>Error in display execute " . $stmt->errorCode() . "</p>\n<p>Message " . implode($stmt->errorInfo()) . "</p>\n";
            exit(1);
        }
        unset($stmt);
        unset($status);
        unset($row);
    }
    ?>
    <div class="container-fluid text-white">
        <?php
        monitoring();
        ?>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="./js/bootstrap/jquery-3.5.1.slim.min.js"></script>
    <script src="./js/bootstrap/popper.min.js"></script>
    <script src="./js/bootstrap/bootstrap.min.js"></script>
</body>